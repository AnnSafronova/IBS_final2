Action()
{

	lr_start_transaction("create_new_user");

	lr_end_transaction("create_new_user",LR_AUTO);

	lr_start_transaction("details_account");

	lr_end_transaction("details_account",LR_AUTO);

	lr_start_transaction("logout");

	lr_end_transaction("logout",LR_AUTO);

	return 0;
}